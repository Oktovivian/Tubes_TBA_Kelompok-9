
test1 = ['FOR', 'kondisi', 'kurawalDpn', 'aksi', 'kurawalBk']

i = 0
status = True
while i < len(test1)-1 and status: